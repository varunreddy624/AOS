import matplotlib.pyplot as plt
import csv
import os
x = []
minTat = []
minct = []
minwt = []
minrt = []
x_coordinate = 0

with open('mlq_rr2_line.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    i = 0
    for row in lines:
        x.append(row[1])
        minTat.append(float(row[6]))
        minrt.append(float(row[3]))
        minwt.append(float(row[4]))
        minct.append(float(row[5]))


plt.plot(x, minct, color='r', label="Completion Time")
plt.plot(x, minwt, color='g', label="Waiting Time")
plt.plot(x, minrt, color='b', label="Burst Time")
plt.plot(x, minTat, color='y', label="TurnAround Time")
plt.legend()
plt.title("Multi Level Queue Algorithm with RR = 2")
os.remove("mlq_rr2_line.csv")
plt.savefig('mlq_rr2_line.png')
