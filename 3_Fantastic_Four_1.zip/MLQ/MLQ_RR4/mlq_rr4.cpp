#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
#include <queue>
#include <random>
#include <fstream>
#include<sstream>

using namespace std;

#define deb(x) cout << #x << " : " << x << "\n";
#define msg(x) cout << x;

typedef long long int lli;

vector<string> PROCESS_TYPES = { "interactive", "system", "batch" };

lli current_time = 0;  //simulates system clock
int MAX_PROCESSES = 10;
int MIN_PROCESSES = 5;
int RR_QUANTA = 4;

/*when you see sp, think system processes
when you see ip, think iteractive processes
when you see bp, think batch processes
*/


struct process
{
    int P_ID;     //process ID
    int AT;       //arrival time
    int BT;       //burst time
    int Priority; //priority time
    int CT;       //completion time
    int TAT;      //turn around time
    int WT;       //waiting time
    int RT;       //response time
    int rem_BT;    //remaining burst time. Used in RR
    string process_type;    //type of process. Its value is one of the values from PROCESS_TYPES
    bool first_run = true;
    string name;
    bool is_io;
    vector<lli> cpu_burst_start;
    vector<lli> cpu_burst_end;
};
bool cmp_min(process& one, process& two)
{
    if (one.AT == two.AT)
    {
        if (one.Priority == two.Priority)
        {
            return one.P_ID < two.P_ID;
        }
        return one.Priority < two.Priority; //smaller priority gets high prefereeeence
    }
    return one.AT < two.AT;
}

bool cmp_pid(process& p1, process& p2)
{
    return p1.P_ID < p2.P_ID;
}

bool cmp_AT(process& p1, process& p2)
{
    if (p1.AT == p2.AT)
    {
        if (p1.Priority == p2.Priority)
        {
            return p1.P_ID < p2.P_ID;
        }
        return p1.Priority < p2.Priority;
    }
    return p1.AT < p2.AT;
}

struct CompareProcessMin
{
    bool operator()(process const& p1, process const& p2)
    {
        if (p1.Priority == p2.Priority)
        {
            if (p1.AT == p2.AT)
            {
                return p1.P_ID > p2.P_ID;
            }
            return p1.AT > p2.AT;
        }
        return p1.Priority > p2.Priority; // small number Higher Priority
    }
};
struct CompareProcessMax
{
    bool operator()(process const& p1, process const& p2)
    {
        if (p1.Priority == p2.Priority)
        {
            if (p1.AT == p2.AT)
            {
                return p1.P_ID > p2.P_ID;
            }
            return p1.AT > p2.AT;
        }
        return p1.Priority < p2.Priority; // large number Higher Priority
    }
};

void schedule_system_processes(vector<process>& info_sp, vector<process>& completed_sp)
{
    //int current_time = 0;
    if (!info_sp.empty())
    {
        priority_queue<process, vector<process>, CompareProcessMin> minHeap_sp;
        sort(info_sp.begin(), info_sp.end(), cmp_min);
        int index_in_info_sp = 0;
        minHeap_sp.push(info_sp[index_in_info_sp]);
        current_time = info_sp[index_in_info_sp].AT;
        index_in_info_sp++;
        while (!minHeap_sp.empty())
        {
            process temp = minHeap_sp.top();
            minHeap_sp.pop();
            temp.RT = current_time - temp.AT;
            temp.cpu_burst_start.push_back(current_time);
            temp.CT = temp.BT + current_time;
            current_time = temp.CT;
            temp.cpu_burst_end.push_back(current_time);
            temp.TAT = temp.CT - temp.AT;
            temp.WT = temp.TAT - temp.BT;
            completed_sp.push_back(temp);
            while (index_in_info_sp < info_sp.size() && info_sp[index_in_info_sp].AT <= current_time)
            {
                minHeap_sp.push(info_sp[index_in_info_sp++]);
            }
            if (minHeap_sp.empty() && index_in_info_sp < info_sp.size())
            {
                minHeap_sp.push(info_sp[index_in_info_sp]);
                current_time = info_sp[index_in_info_sp].AT;
                index_in_info_sp++;
            }
        }
    }
}

void populate_readyip_queue(vector<process>& info_ip, queue<process*>& ready_ip, int* info_ip_idx)
{
    while (*info_ip_idx < info_ip.size())
    {
        if (info_ip[*info_ip_idx].AT <= current_time)
        {
            ready_ip.push(&(info_ip[*info_ip_idx]));
            (*info_ip_idx)++;
        }
        else break;
    }
}


void schedule_interactive_processes(vector<process>& info_ip, vector<process>& completed_ip, int rr_quanta)
{
    //deb("1")
    queue<process*> ready_ip;
    sort(info_ip.begin(), info_ip.end(), cmp_min);
    int info_ip_idx = 0;
    //cout << "ip vector size: " << info_ip.size() << "\n";
    while (completed_ip.size() < info_ip.size())
    {
        //deb(2.5)
        //deb(current_time)
        populate_readyip_queue(info_ip, ready_ip, &info_ip_idx);
        if (ready_ip.empty())
        {
            //deb(info_ip_idx)
            //deb(info_ip.size())
            if (info_ip_idx >= info_ip.size()) break;
            else current_time += info_ip[info_ip_idx].AT;
        }
        //deb(3)
        while (!ready_ip.empty())
        {
            process* cur = ready_ip.front();
            cur->cpu_burst_start.push_back(current_time);
            if (cur->first_run)
            {
                //deb(3.5)
                cur->RT = current_time - cur->AT;
                cur->first_run = false;
            }
            cur->rem_BT -= rr_quanta;
            //deb(4)
            if (cur->rem_BT <= 0)
            {
                //deb(5)
                current_time += rr_quanta + cur->rem_BT;
                cur->cpu_burst_end.push_back(current_time);
                cur->CT = current_time;
                cur->TAT = cur->CT - cur->AT;
                cur->WT = cur->TAT - cur->BT;
                completed_ip.push_back(*cur);
                ready_ip.pop();
                cur = NULL;
            }
            else
            {
                //deb(6)
                current_time += rr_quanta;
                cur->cpu_burst_end.push_back(current_time);
                ready_ip.pop();
            }
            populate_readyip_queue(info_ip, ready_ip, &info_ip_idx);
            if (cur) ready_ip.push(cur);
            //deb(7)
            //cout << "for loop: ready_queue size: " << ready_ip.size() << "\n";
        }
    }
    //cout << "completed ip vector size: " << completed_ip.size() << "\n";
}

void populate_readybp_queue(vector<process>& info_bp, queue<process*>& ready_bp, int* info_bp_idx)
{
    while (*info_bp_idx < info_bp.size())
    {
        if (info_bp[*info_bp_idx].AT <= current_time)
        {
            ready_bp.push(&(info_bp[*info_bp_idx]));
            (*info_bp_idx)++;
        }
        else break;
    }
}

void schedule_batch_processes(vector<process>& info_bp, vector<process>& completed_bp)
{
    queue<process*> ready_bp;
    sort(info_bp.begin(), info_bp.end(), cmp_min);
    int info_bp_idx = 0;
    while (completed_bp.size() < info_bp.size())
    {
        populate_readybp_queue(info_bp, ready_bp, &info_bp_idx);
        //cout << "ready queue size: " << ready_ip.size() << "\n";
        if (ready_bp.empty())
        {
            if (info_bp_idx >= info_bp.size()) break;
            else current_time += info_bp[info_bp_idx].AT;
        }
        else
        {
            while (!ready_bp.empty())
            {
                process* cur = ready_bp.front();
                cur->cpu_burst_start.push_back(current_time);
                current_time += cur->BT;
                cur->CT = current_time;
                cur->RT = current_time - cur->AT;
                cur->TAT = cur->CT - cur->AT;
                cur->WT = cur->TAT - cur->BT;
                cur->cpu_burst_end.push_back(current_time);
                completed_bp.push_back(*cur);
                ready_bp.pop();
                populate_readybp_queue(info_bp, ready_bp, &info_bp_idx);
            }
        }
    }
}

void read_processes_from_inp(vector<process>& all_cpu_processes, vector<process>& all_io_processes)
{
    ifstream fin("in.txt");
    // string header;
    // getline(fin, header);
    string line;
    process cur_process;
    string param;
    while (getline(fin, line))
    {
        stringstream ss(line);
        getline(ss, param, ',');
        cur_process.P_ID = stoi(param);
        getline(ss, param, ',');
        cur_process.name = param;
        getline(ss, param, ',');
        if (param[0] == 'I') cur_process.is_io = true;
        else cur_process.is_io = false;
        getline(ss, param, ',');
        cur_process.Priority = stoi(param);
        getline(ss, param, ',');
        cur_process.AT = stoi(param);
        getline(ss, param);
        cur_process.BT = stoi(param);
        cur_process.process_type = PROCESS_TYPES[rand() % PROCESS_TYPES.size()];
        cur_process.rem_BT = cur_process.BT;
        if(cur_process.is_io) all_io_processes.push_back(cur_process);
        else all_cpu_processes.push_back(cur_process);
    }
    fin.close();
}

void printVec(vector<process>& v)
{
    for (process p : v)
    {
        cout << p.P_ID << "\t" << p.AT << "\t" << p.BT << "\t" << p.CT << "\t" << p.TAT << "\t" << p.WT << "\t" << p.RT <<"\t"<<p.process_type<< "\t";
        if(p.is_io) cout<<"io\n";
        else cout<<"cpu\n";
    }
}

void make_csv_for_gantt(vector<process>& all_completed)
{
    //ofstream fout("mlq_rr4_gantt.csv", ios_base::app);
    ofstream fout("mlq_rr4_gantt.csv");
    for(process p : all_completed)
    {
        for(int i = 0; i < p.cpu_burst_start.size(); i++)
        {
            fout<<p.P_ID<<","<<p.name<<",";
            if(p.is_io) fout<<"1,";
            else fout<<"0,";
            fout<<p.cpu_burst_start[i]<<","<<p.cpu_burst_end[i]<<"\n";
        }
    }
    fout.close();
}

void write_op_to_csv(vector<process>& all_completed)
{
    ofstream fout_tat("mlq_rr4_tat.txt");
    ofstream fout_ct("mlq_rr4_ct.txt");
    ofstream fout_wt("mlq_rr4_wt.txt");
    ofstream fout_rt("mlq_rr4_rt.txt");
    ofstream fout_bt("mlq_rr4_bt.txt");
    for(int i = 0; i < all_completed.size(); i++)
    {
        if(i == all_completed.size() - 1)
        {
            fout_tat <<all_completed[i].TAT;
            fout_ct <<all_completed[i].CT;
            fout_wt<<all_completed[i].WT;
            fout_rt<<all_completed[i].RT;
            fout_bt<<all_completed[i].BT;
        }
        else
        {
            fout_tat <<all_completed[i].TAT<<",";
            fout_ct <<all_completed[i].CT<<",";
            fout_wt<<all_completed[i].WT<<",";
            fout_rt<<all_completed[i].RT<<",";
            fout_bt<<all_completed[i].BT<<",";
        }
        
    }
    fout_tat.close();
    fout_ct.close();
    fout_wt.close();
    fout_rt.close();
    fout_bt.close();
}

void make_csv_for_stacked_bars(vector<process>& all_completed)
{
    ofstream fout_bt_ct("mlq_rr4_bt_wt.csv");
    for(int i = 0; i < all_completed.size(); i++)
    {
        fout_bt_ct<<all_completed[i].name<<","<<all_completed[i].BT<<","<<all_completed[i].WT<<"\n";
    }
    fout_bt_ct.close();
}

void make_csv_for_avgs(vector<process>& all_completed)
{
    double avg_tat = 0;
    double avg_rt = 0;
    double avg_ct = 0;
    double avg_wt = 0;
    for(int i = 0; i < all_completed.size(); i++)
    {
        avg_tat += all_completed[i].TAT;
        avg_ct += all_completed[i].CT;
        avg_rt += all_completed[i].RT;
        avg_wt += all_completed[i].WT;
    }
    avg_tat /= all_completed.size();
    avg_ct /= all_completed.size();
    avg_rt /= all_completed.size();
    avg_wt /= all_completed.size();
    ofstream fout("./../../allout.txt",ios_base::app);
    fout<<avg_tat<<",";
    fout<<avg_ct<<",";
    fout<<avg_rt<<",";
    fout<<avg_wt<<"\n";
    fout.close();
}

void make_csv_for_line(vector<process>& all_completed)
{
    ofstream fout("mlq_rr4_line.csv");
    for(int i = 0; i < all_completed.size(); i++)
    {
        fout<<all_completed[i].P_ID<<",";
        fout<<all_completed[i].name<<",";
        if(all_completed[i].is_io) fout<<"1,";
        else fout<<"0,";
        fout<<all_completed[i].BT<<",";
        fout<<all_completed[i].WT<<",";
        fout<<all_completed[i].CT<<",";
        fout<<all_completed[i].TAT<<"\n";
    }
    fout.close();
}

int main()
{
    srand(time(NULL));
    vector<process> info_sp;   //collection of all system processes in the system
    vector<process> info_ip;    //collection of all interactive processes in the system
    vector<process> info_bp;    //collection of all batch processes in the system
    vector<process> all_cpu_processes;
    vector<process> all_io_processes;
    read_processes_from_inp(all_cpu_processes, all_io_processes);
    for (process p : all_cpu_processes)
    {
        if (p.process_type == "system") info_sp.push_back(p);
        else if (p.process_type == "interactive") info_ip.push_back(p);
        else if (p.process_type == "batch") info_bp.push_back(p);
    }
    vector<process> completed_sp;
    schedule_system_processes(info_sp, completed_sp);
    vector<process> completed_ip;
    schedule_interactive_processes(info_ip, completed_ip, RR_QUANTA);
    vector<process> completed_bp;
    schedule_batch_processes(info_bp, completed_bp);
    // cout << "PID \t AT \t BT \t CT \t TAT \t WT \t RT \t type \t cpu/io \n";
    // printVec(completed_sp);
    // printVec(completed_ip);
    // printVec(completed_bp);
    for(int i = 0; i < all_io_processes.size(); i++)
    {
        all_io_processes[i].cpu_burst_start.push_back(all_io_processes[i].AT);
        all_io_processes[i].CT = all_io_processes[i].AT + all_io_processes[i].BT;
        all_io_processes[i].RT = 0;
        all_io_processes[i].TAT = all_io_processes[i].BT;
        all_io_processes[i].WT = 0;
        all_io_processes[i].cpu_burst_end.push_back(all_io_processes[i].CT);
    }
    vector<process> all_completed;
    all_completed.insert(all_completed.end(), completed_sp.begin(), completed_sp.end());
    all_completed.insert(all_completed.end(), completed_ip.begin(), completed_ip.end());
    all_completed.insert(all_completed.end(), completed_bp.begin(), completed_bp.end());
    all_completed.insert(all_completed.end(), all_io_processes.begin(), all_io_processes.end());
    sort(all_completed.begin(), all_completed.end(), cmp_pid);
    // cout << "PID \t AT \t BT \t CT \t TAT \t WT \t RT \t type \t cpu/io \n";
    // printVec(all_completed);
    make_csv_for_gantt(all_completed);
    make_csv_for_avgs(all_completed);
    make_csv_for_stacked_bars(all_completed);
    make_csv_for_line(all_completed);
    return 0;
}
