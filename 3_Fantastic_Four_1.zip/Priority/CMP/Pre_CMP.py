
import matplotlib.pyplot as plt
import csv
import os
x = []
minTat = []
maxTat = []
minct = []
maxct = []
minwt = []
maxwt = []
minrt = []
maxrt = []
x_coordinate = 0
with open('pri_pre_tat1.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        x.append(x_coordinate)
        x_coordinate += 1
        minTat.append(float(row[0]))
with open('pri_pre_tat2.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        maxTat.append(float(row[0]))
with open('pri_pre_rt1.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        minrt.append(float(row[0]))
with open('pri_pre_rt2.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        maxrt.append(float(row[0]))
with open('pri_pre_wt1.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        minwt.append(float(row[0]))
with open('pri_pre_wt2.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        maxwt.append(float(row[0]))
with open('pri_pre_ct1.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        minct.append(float(row[0]))
with open('pri_pre_ct2.csv', 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        maxct.append(float(row[0]))
####################################################
fig, ax = plt.subplots()
plt.plot(x, minTat,  linestyle='dashed',
         marker='o', label="Small Number => High priority")
plt.plot(x, maxTat,  linestyle='dashed',
         marker='o', label="Large Number => High priority")
#plt.bar(xAxis, avgWT)
plt.title("Turn Around Time")
plt.xlabel('Test Cases')
plt.ylabel('Time')
plt.legend(loc='best')
# plt.show()
plt.savefig("./../../OUT/Pre_TAT_LNHP_HNHP_CMP.png")
plt.clf()
#####################################################
####################################################
fig, ax = plt.subplots()
plt.plot(x, minct,  linestyle='dashed',
         marker='o', label="Small Number => High priority")
plt.plot(x, maxct,  linestyle='dashed',
         marker='o', label="Large Number => High priority")
#plt.bar(xAxis, avgWT)
plt.title("Completion Time")
plt.xlabel('Test Cases')
plt.ylabel('Time')
plt.legend(loc='best')
# plt.show()
plt.savefig("./../../OUT/Pre_CT_LNHP_HNHP_CMP.png")
plt.clf()
#####################################################
####################################################
fig, ax = plt.subplots()
plt.plot(x, minrt,  linestyle='dashed',
         marker='o', label="Small Number => High priority")
plt.plot(x, maxrt,  linestyle='dashed',
         marker='o', label="Large Number => High priority")
#plt.bar(xAxis, avgWT)
plt.title("Response Time")
plt.xlabel('Test Cases')
plt.ylabel('Time')
plt.legend(loc='best')
# plt.show()
plt.savefig("./../../OUT/Pre_RT_LNHP_HNHP_CMP.png")
plt.clf()
#####################################################
####################################################
fig, ax = plt.subplots()
plt.plot(x, minwt,  linestyle='dashed',
         marker='o', label="Small Number => High priority")
plt.plot(x, maxwt,  linestyle='dashed',
         marker='o', label="Large Number => High priority")
#plt.bar(xAxis, avgWT)
plt.title("Waiting Time")
plt.xlabel('Test Cases')
plt.ylabel('Time')
plt.legend(loc='best')
# plt.show()
plt.savefig("./../../OUT/Pre_WT_LNHP_HNHP_CMP.png")
plt.clf()
#####################################################
os.remove('pri_pre_tat1.csv')
os.remove('pri_pre_tat2.csv')
os.remove('pri_pre_rt1.csv')
os.remove('pri_pre_rt2.csv')
os.remove('pri_pre_wt1.csv')
os.remove('pri_pre_wt2.csv')
os.remove('pri_pre_ct1.csv')
os.remove('pri_pre_ct2.csv')
