#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
#include <queue>
#include <random>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <string>
#include <string.h>
using namespace std;
#define deb(x) cout << #x << " : " << x << "\n";
#define msg(x) cout << x;
struct process
{
    int P_ID;       //process ID
    int AT;         //arrival time
    int BT;         //burst time
    int Orig_BT;    //original burst time
    int Priority;   //priority time
    int CT;         //completion time
    int TAT;        //turn around time
    int WT;         //waiting time
    int RT;         //response time
    bool first_exe; //tells whether it is first execution of process or not
    bool io_bound = false;
    char ProcessName[32] = ""; //Process Name
};
bool sort_final(process &one, process &two)
{
    return one.P_ID < two.P_ID;
}
bool cmp_min(process &one, process &two)
{
    if (one.AT == two.AT)
    {
        if (one.Priority == two.Priority)
        {
            return one.P_ID < two.P_ID;
        }
        return one.Priority < two.Priority; //smaller priority gets high prefereeeence
    }
    return one.AT < two.AT;
}
struct proc_info
{
    int startTime;
    int endTime;
    int ProcessID;
    bool is_io_bound;
    char ProcessName[32];
};
struct CompareProcessMin
{
    bool operator()(process const &p1, process const &p2)
    {
        if (p1.Priority == p2.Priority)
        {
            if (p1.AT == p2.AT)
            {
                return p1.P_ID > p2.P_ID;
            }
            return p1.AT > p2.AT;
        }
        return p1.Priority > p2.Priority; // small number Higher Priority
    }
};
struct CompareProcessMax
{
    bool operator()(process const &p1, process const &p2)
    {
        if (p1.Priority == p2.Priority)
        {
            if (p1.AT == p2.AT)
            {
                return p1.P_ID > p2.P_ID;
            }
            return p1.AT > p2.AT;
        }
        return p1.Priority < p2.Priority; // large number Higher Priority
    }
};
int main()
{
    srand(time(NULL));
    int choice;
    int num_process = 0;
    vector<process> info_cpu_bound;
    vector<process> info_io_bound;
    ifstream input;
    ofstream gant1;
    ofstream gant2;
    ofstream f1;
    ofstream f2;
    ofstream perprocessBtWt1;
    ofstream perprocessBtWt2;
    string filename("./../../allout.txt");
    ofstream allOutput;
    allOutput.open(filename, std::ios_base::app);
    gant1.open("LNHP/CSV/gantt.csv", fstream::out);
    gant2.open("HNHP/CSV/gantt.csv", fstream::out);
    perprocessBtWt1.open("LNHP/CSV/BtWt.csv", fstream::out);
    perprocessBtWt2.open("HNHP/CSV/BtWt.csv", fstream::out);
    f1.open("LNHP/CSV/PerProcess_data.csv", fstream::out);
    //LNHP: low number high prio
    f2.open("HNHP/CSV/PerProcess_data.csv", fstream::out);
    //LNHP: high number high prio
    //input.open("TEST/test1.csv", fstream::in);
    //test1.csv low num high priority,
    //TAT 11.166 , WT 6.8(non-pre)

    //input.open("TEST/test2.csv", fstream::in);
    //test2.csv high num high priority,
    //TAT 8.2 , WT 5.2(non-pre)

    //input.open("TEST/test3.csv", fstream::in);
    //test3.csv low num high priority,
    //TAT 8.8 , WT 5.6(non-pre)

    input.open("TEST/test4.csv", fstream::in);
    //test4.csv high num high priority,
    //TAT 7.6 , WT 4.6(pre)

    //input.open("TEST/test5.csv", fstream::in);
    //test5.csv low num high priority,
    //TAT 8.4 , WT 4.4(non-pre)

    if (input.is_open() == false)
    {
        msg("Failed to open");
    }
    //for (int i = 0; i < 100; ++i)
    //{
    info_cpu_bound.clear();
    info_io_bound.clear();
    string csvLine;
    while (getline(input, csvLine))
    {
        process temp;
        istringstream csvStream(csvLine);
        vector<string> csvColumn;
        string csvElement;
        getline(csvStream, csvElement, ',');
        temp.P_ID = stoi(csvElement);
        //deb(temp.P_ID);
        getline(csvStream, csvElement, ',');
        strcpy(temp.ProcessName, csvElement.c_str());
        //deb(temp.ProcessName);
        bool io_bound = false;
        if (csvElement[0] == 'I')
        {
            io_bound = true;
        }
        else
        {
            num_process++;
        }
        temp.io_bound = io_bound;
        //deb(temp.io_bound);
        getline(csvStream, csvElement, ','); //ignore process Type
        //deb(csvElement);
        getline(csvStream, csvElement, ','); //get process Priority
        temp.Priority = stoi(csvElement);
        //deb(temp.Priority);
        getline(csvStream, csvElement, ','); //get process AT
        temp.AT = stoi(csvElement);
        //deb(temp.AT);
        getline(csvStream, csvElement); //get process BT
        temp.BT = stoi(csvElement);
        //deb(temp.BT);
        temp.Orig_BT = temp.BT;
        temp.WT = 0;
        temp.TAT = 0;
        temp.RT = 0;
        temp.CT = 0;
        temp.first_exe = true;
        if (io_bound == true)
        {
            temp.CT = temp.AT + temp.BT;
            temp.TAT = temp.BT;
            temp.RT = 0;
            temp.first_exe = false;
            info_io_bound.push_back(temp);
        }
        else
        {
            info_cpu_bound.push_back(temp);
        }
        //msg("")
    }
    { //use low number as high priority
        vector<proc_info> timestamp_val;
        int current_time = 0;
        process temp;
        priority_queue<process, vector<process>, CompareProcessMin> minHeap;
        sort(info_cpu_bound.begin(), info_cpu_bound.end(), cmp_min);
        int index_in_array = 0;
        minHeap.push(info_cpu_bound[index_in_array]);
        current_time = info_cpu_bound[index_in_array].AT;
        index_in_array++;
        vector<process> ans;
        while (minHeap.empty() == false)
        {
            temp = minHeap.top();
            minHeap.pop();
            if (temp.first_exe == true)
            {
                temp.RT = current_time;
                temp.first_exe = false;
            }
            if (temp.BT > 1)
            {
                proc_info temp_per_prc;
                temp_per_prc.startTime = current_time;
                temp_per_prc.endTime = current_time + 1;
                temp_per_prc.is_io_bound = temp.io_bound;
                strcpy(temp_per_prc.ProcessName, temp.ProcessName);
                temp_per_prc.ProcessID = temp.P_ID;
                timestamp_val.push_back(temp_per_prc);

                temp.BT = temp.BT - 1;
                current_time++;
                minHeap.push(temp);
            }
            else if (temp.BT == 1)
            {
                proc_info temp_per_prc;
                temp_per_prc.startTime = current_time;
                temp_per_prc.endTime = current_time + 1;
                temp_per_prc.is_io_bound = temp.io_bound;
                strcpy(temp_per_prc.ProcessName, temp.ProcessName);
                temp_per_prc.ProcessID = temp.P_ID;
                timestamp_val.push_back(temp_per_prc);

                temp.BT = 0;
                current_time++;
                temp.CT = current_time;
                temp.TAT = temp.CT - temp.AT;
                temp.WT = temp.TAT - temp.Orig_BT;
                ans.push_back(temp);
            }
            while (index_in_array < num_process && info_cpu_bound[index_in_array].AT <= current_time)
            {
                minHeap.push(info_cpu_bound[index_in_array++]);
            }
            if (minHeap.empty() && index_in_array < num_process)
            {
                minHeap.push(info_cpu_bound[index_in_array]);
                current_time = info_cpu_bound[index_in_array].AT;
                index_in_array++;
            }
        }
        double avg_tat = 0, avg_rt = 0, avg_wt = 0, avg_ct = 0;
        vector<process> Final = ans;
        Final.insert(Final.end(), info_io_bound.begin(), info_io_bound.end());
        sort(Final.begin(), Final.end(), sort_final);
        for (unsigned int i = 0; i < Final.size(); i++)
        {
            avg_tat += Final[i].TAT;
            avg_rt += Final[i].RT;
            avg_wt += Final[i].WT;
            avg_ct += Final[i].CT;
            // PID,Pname,I/O(CPU),BT,WT,CT,TAT
            f1 << Final[i].P_ID << ',';
            f1 << Final[i].ProcessName << ',';
            f1 << Final[i].io_bound << ',';
            f1 << Final[i].Orig_BT << ',';
            f1 << Final[i].WT << ',';
            f1 << Final[i].CT << ',';
            f1 << Final[i].TAT << '\n';
            perprocessBtWt1 << Final[i].ProcessName << ",";
            perprocessBtWt1 << Final[i].Orig_BT << ",";
            perprocessBtWt1 << Final[i].WT << "\n";
        }
        for (unsigned int lpk = 0; lpk < info_io_bound.size(); lpk++)
        {
            gant1 << info_io_bound[lpk].P_ID << ',';
            gant1 << info_io_bound[lpk].ProcessName << ',';
            gant1 << info_io_bound[lpk].io_bound << ',';
            gant1 << info_io_bound[lpk].AT << ',';
            gant1 << info_io_bound[lpk].CT << '\n';
        }
        for (unsigned int lpk = 0; lpk < timestamp_val.size(); lpk++)
        {
            gant1 << timestamp_val[lpk].ProcessID << ',';
            gant1 << timestamp_val[lpk].ProcessName << ',';
            gant1 << timestamp_val[lpk].is_io_bound << ',';
            gant1 << timestamp_val[lpk].startTime << ',';
            gant1 << timestamp_val[lpk].endTime << '\n';
        }

        avg_ct /= Final.size();
        avg_rt /= Final.size();
        avg_wt /= Final.size();
        avg_tat /= Final.size();
        allOutput << avg_tat << ',';
        allOutput << avg_ct << ',';
        allOutput << avg_rt << ',';
        allOutput << avg_wt << '\n';
        // msg("Low Number high Priority");
        deb(avg_tat);
        deb(avg_rt);
        deb(avg_wt);
        deb(avg_ct);
    }
    { //use High number as high priority
        int current_time = 0;
        vector<proc_info> timestamp_val;
        process temp;
        priority_queue<process, vector<process>, CompareProcessMax> maxHeap;
        sort(info_cpu_bound.begin(), info_cpu_bound.end(), cmp_min);
        int index_in_array = 0;
        maxHeap.push(info_cpu_bound[index_in_array]);
        current_time = info_cpu_bound[index_in_array].AT;
        index_in_array++;
        vector<process> ans;
        while (maxHeap.empty() == false)
        {
            temp = maxHeap.top();
            maxHeap.pop();
            if (temp.first_exe == true)
            {
                temp.RT = current_time - temp.AT;
                temp.first_exe = false;
            }
            if (temp.BT > 1)
            {
                proc_info temp_per_prc;
                temp_per_prc.startTime = current_time;
                temp_per_prc.endTime = current_time + 1;
                temp_per_prc.is_io_bound = temp.io_bound;
                strcpy(temp_per_prc.ProcessName, temp.ProcessName);
                temp_per_prc.ProcessID = temp.P_ID;
                timestamp_val.push_back(temp_per_prc);

                temp.BT = temp.BT - 1;
                current_time++;
                maxHeap.push(temp);
            }
            else if (temp.BT == 1)
            {
                proc_info temp_per_prc;
                temp_per_prc.startTime = current_time;
                temp_per_prc.endTime = current_time + 1;
                temp_per_prc.is_io_bound = temp.io_bound;
                strcpy(temp_per_prc.ProcessName, temp.ProcessName);
                temp_per_prc.ProcessID = temp.P_ID;
                timestamp_val.push_back(temp_per_prc);

                temp.BT = 0;
                current_time++;
                temp.CT = current_time;
                temp.TAT = temp.CT - temp.AT;
                temp.WT = temp.TAT - temp.Orig_BT;
                ans.push_back(temp);
            }
            while (index_in_array < num_process && info_cpu_bound[index_in_array].AT <= current_time)
            {
                maxHeap.push(info_cpu_bound[index_in_array++]);
            }
            if (maxHeap.empty() && index_in_array < num_process)
            {
                maxHeap.push(info_cpu_bound[index_in_array]);
                current_time = info_cpu_bound[index_in_array].AT;
                index_in_array++;
            }
        }
        double avg_tat = 0, avg_rt = 0, avg_wt = 0, avg_ct = 0;
        vector<process> Final = ans;
        Final.insert(Final.end(), info_io_bound.begin(), info_io_bound.end());
        sort(Final.begin(), Final.end(), sort_final);
        for (unsigned int i = 0; i < Final.size(); i++)
        {
            avg_tat += Final[i].TAT;
            avg_rt += Final[i].RT;
            avg_wt += Final[i].WT;
            avg_ct += Final[i].CT;
            // PID,Pname,I/O(CPU),BT,WT,CT,TAT
            f2 << Final[i].P_ID << ',';
            f2 << Final[i].ProcessName << ',';
            f2 << Final[i].io_bound << ',';
            f2 << Final[i].Orig_BT << ',';
            f2 << Final[i].WT << ',';
            f2 << Final[i].CT << ',';
            f2 << Final[i].TAT << '\n';
            perprocessBtWt2 << Final[i].ProcessName << ",";
            perprocessBtWt2 << Final[i].Orig_BT << ",";
            perprocessBtWt2 << Final[i].WT << "\n";
        }
        for (unsigned int lpk = 0; lpk < info_io_bound.size(); lpk++)
        {
            gant2 << info_io_bound[lpk].P_ID << ',';
            gant2 << info_io_bound[lpk].ProcessName << ',';
            gant2 << info_io_bound[lpk].io_bound << ',';
            gant2 << info_io_bound[lpk].AT << ',';
            gant2 << info_io_bound[lpk].CT << '\n';
        }
        for (unsigned int lpk = 0; lpk < timestamp_val.size(); lpk++)
        {
            gant2 << timestamp_val[lpk].ProcessID << ',';
            gant2 << timestamp_val[lpk].ProcessName << ',';
            gant2 << timestamp_val[lpk].is_io_bound << ',';
            gant2 << timestamp_val[lpk].startTime << ',';
            gant2 << timestamp_val[lpk].endTime << '\n';
        }
        avg_ct /= Final.size();
        avg_rt /= Final.size();
        avg_wt /= Final.size();
        avg_tat /= Final.size();
        allOutput << avg_tat << ',';
        allOutput << avg_ct << ',';
        allOutput << avg_rt << ',';
        allOutput << avg_wt << '\n';
        deb(avg_tat);
        deb(avg_rt);
        deb(avg_wt);
        deb(avg_ct);
    }
    allOutput.close();
    f1.close();
    perprocessBtWt1.close();
    perprocessBtWt2.close();
    f2.close();
    return 0;
}
