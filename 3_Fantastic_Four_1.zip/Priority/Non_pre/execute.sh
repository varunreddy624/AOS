#!/bin/bash
g++ "main.cpp" -o "main"
./main
cd HNHP/SCRIPT/
python3 bars.py
python3 gantt.py
python3 line.py
cd ../../
cd LNHP/SCRIPT/
python3 bars.py
python3 gantt.py
python3 line.py
cd ../../
rm "main"
cp LNHP/OUTPUT/* OUT/LNHP/
cp HNHP/OUTPUT/* OUT/HNHP/
