import matplotlib.pyplot as plt
import csv
import os
x = []
minTat = []
minct = []
minwt = []
minrt = []
x_coordinate = 0
with open("./../CSV/PerProcess_data.csv", 'r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        x.append(row[1])
        minTat.append(float(row[6]))
        minrt.append(float(row[3]))
        minwt.append(float(row[4]))
        minct.append(float(row[5]))


plt.plot(x, minct, color='r', label="Completion Time")
plt.plot(x, minwt, color='g', label="Waiting Time")
plt.plot(x, minrt, color='b', label="Burst Time")
plt.plot(x, minTat, color='y', label="TurnAround Time")
plt.title('Priority (High Number High Priority) Non Pre-emptive')
plt.legend()
# plt.show()
plt.savefig("./../OUTPUT/PerProcess_data_NPre_Pri_HNHP.png")
os.remove("./../CSV/PerProcess_data.csv")
