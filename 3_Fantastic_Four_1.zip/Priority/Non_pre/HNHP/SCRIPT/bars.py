import matplotlib.pyplot as plt
import numpy as np
import os
file = open("./../CSV/BtWt.csv", "r")
bt_list = []
wt_list = []
proc_names_list = []
while(True):
    line = file.readline()
    if not line:
        break
    data = line.split(',')
    proc_names_list.append(data[0])
    bt_list.append(int(data[1]))
    wt_list.append(int(data[2]))
file.close()

# print(proc_names_list)
# print(bt_list)
# print(wt_list)
num_bars = len(bt_list)
fig, ax = plt.subplots()
ind = np.arange(num_bars)
bar_width = 0.35

p1 = ax.bar(proc_names_list, wt_list, bar_width, label='WT')
p2 = ax.bar(proc_names_list, bt_list, bar_width, label='BT')
ax.set_ylabel('Time')
ax.set_title('Priority (High Number High Priority) Non Pre-emptive')
#ax.set_xticks(ind, labels=proc_names_list)
ax.set_xlabel('Process name')
ax.legend()
plt.savefig('./../OUTPUT/BtWt_NPre_Pri_HNHP.png')
# plt.show()
os.remove("./../CSV/BtWt.csv")
