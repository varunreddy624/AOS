Team: 3
Name: Fantastic Four

#Report Name
3_Fantastic_Four.pdf

#Execution instruction.
In order to execute , give execute permission to "execute.sh" & all the CPP and Python scritps in inner folders.

then open linux terminal in same directory as this file and run.

"./execute.sh"

for round robin case (for trying it in different hyperparameter) 
it will prompt and ask any five (non zero integer) as time quanta.

It will execute all the CPP files  and python scripts, and all the output will be generated in folder "./OUT"
and additionally four extra Images(in Marron color) will be generated in current directory, these images are for inter-process 
comparision for various performance parameters, and the images generated in "./OUT" are the images for generating staticstics 
per Processes.


Other modules which are required for this projects are.

Cpp modules required are
g++

Python modules required are
python3
matplotlib
numpy
csv
os

Note: Do not delete any script or any other file.
