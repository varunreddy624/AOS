#include<iostream>
#include <algorithm> 
#include <queue> 
#include<iomanip>
#include<climits>
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<queue>
#include<sstream>
#include <chrono>
#include <thread>
using namespace std;

struct process_struct
{
  int pid;
  int arrival_time;
  int burst_time;
  int completion_time;
  int waiting_time;
  int turnaroundtime;
  int rt;
  int start_time;
  int remaining_burst;
};

bool comp(struct process_struct a,struct process_struct b)
{
   int x =a.pid;
   int y =b.pid;
   if(x>y){
       return false;
   }
   return true;
}

bool compare(struct process_struct a,struct process_struct b)
{
   int x =a.arrival_time;
   int y =b.arrival_time;
   if(x>y){
       return false;
   }
   return true;
}



int main(int arc,char *argv[])
{
    ofstream tat1;
    ofstream wt1;
    ofstream rt1;
    ofstream ct1;
    ofstream tq1;
    int add=2;
    tq1.open("rr_tq.csv",fstream::out);
    tat1.open("rr_tat1.csv", fstream::out);
    wt1.open("rr_wt1.csv", fstream::out);
    rt1.open("rr_rt1.csv", fstream::out);
    ct1.open("rr_ct1.csv", fstream::out);
    for(int num=0;num<5;num++)
    {
    int n,index;
    int cpu_utilization;
    queue<int> que;
    int current_time = 0,max_completion_time;
    int completed = 0,tq, total_idle_time=0,length_cycle;
    //cout<<"Enter total number of processes: ";   
    ifstream fin("RR.txt", ios::in);
    string processn;
    getline(fin, processn);
    n=stoi(processn);
    struct process_struct process_block[n];
    string process;
    int j=0;
    while(getline(fin, process))
    {
        stringstream ss(process);
        vector<string> params;
        string param;
        for(int i = 0; i < 2; i++)
        {
            if(getline(ss, param, ',')) params.push_back(param);
        }
        process_block[j].pid=j;
        process_block[j].arrival_time=stoi(params[0]);
        process_block[j].burst_time=stoi(params[1]);
        process_block[j].remaining_burst=process_block[j].burst_time;
        j++;


    }

    bool visited[n]={false},is_first_process=true;
    float sum_tat=0,sum_wt=0,sum_rt=0;

    cout<<"\nEnter time quanta: ";
    cin>>tq;
    tq1<<tq<<'\n';


    sort(process_block,process_block+n,compare);
    
    que.push(0);  
    visited[0] = true;
   
    while(completed != n) 
    {
      index = que.front();      
      que.pop();
      
      if(process_block[index].remaining_burst == process_block[index].burst_time)
      {
            process_block[index].start_time = max(current_time,process_block[index].arrival_time);
            total_idle_time += (is_first_process == true) ? 0 : process_block[index].start_time - current_time;
            current_time =  process_block[index].start_time;
            is_first_process = false;
             
      }

      if(process_block[index].remaining_burst-tq > 0)
      {    
            process_block[index].remaining_burst -= tq;
            current_time += tq;
      }
      else 
      {
            current_time += process_block[index].remaining_burst;
            process_block[index].remaining_burst = 0;
            completed++;
            process_block[index].completion_time = current_time;
            process_block[index].turnaroundtime = process_block[index].completion_time - process_block[index].arrival_time;
            process_block[index].waiting_time = process_block[index].turnaroundtime - process_block[index].burst_time;
            process_block[index].rt = process_block[index].start_time - process_block[index].arrival_time;
            sum_tat += process_block[index].turnaroundtime;
            sum_wt += process_block[index].waiting_time;
            sum_rt += process_block[index].rt;
      }

      for(int i = 1; i < n; i++) 
      {
          if(process_block[i].remaining_burst > 0 && process_block[i].arrival_time <= current_time && visited[i] == false) 
          {
            que.push(i);
            visited[i] = true;
          }
      }
      if( process_block[index].remaining_burst> 0) 
          que.push(index);
            
      if(que.empty())
      {
          for(int i = 1; i < n; i++)
          {
            if(process_block[i].remaining_burst > 0)
            {
              que.push(i);
              visited[i] = true;
              break;
            }
          }
      }
   }
  max_completion_time = INT_MIN;
  
  for(int i=0;i<n;i++)
        max_completion_time = max(max_completion_time,process_block[i].completion_time); 
  length_cycle = max_completion_time - process_block[0].arrival_time;  
    
  cpu_utilization = (float)(length_cycle - total_idle_time)/ length_cycle;
  int sum_ct=0;
  sort(process_block, process_block+n , comp);
  for(int i=0;i<n;i++){
    sum_ct+=process_block[i].completion_time;
  }

    tat1 << (float)sum_tat/n << '\n';
    wt1 << (float)sum_wt/n << '\n';
    rt1 << (float)sum_rt/n << '\n';
    ct1<<(float)sum_ct/n<<'\n';
    add+2;
    }
        
    tat1.close();
    wt1.close();
    rt1.close();
    ct1.close();
  return 0;
}
