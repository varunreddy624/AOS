FCFS-

1-FCFS.cpp -input-input.csv output-gives four files
File format-
    1)fcfs_data.csv - pid,pname,i/o(cpu),bt,wt,ct,tat
    2)fcfs_gnan.csv - pid,pname,i/o(cpu),start,end
    3)fcfs.bt.csv - contains all BT of one test case ',' seperated
    4)fcfs_wt.csv - contains all WT of one test case ',' seperated
2-FCFST.cpp -input-FCFS.txt(contains 3 testcases) output-gives four files 
    1.)fcfs_tat1.csv- avg burst times all the processes in each line
    2.)fcfs_rt1.csv-avg response times all the processes in each line
    3.)fcfs_ct1.csv-avg completion times all the processes in each line
    4.)fcfs_wt1.csv-avg waiting times all the processes in each line

Graphs-
1.)fcfs-bar.py- takes fcfs_wt.csv and fcfs_bt.csv as input and pplots a bar plot for each of the process.
2.)fcfs-gnat.py- takes fcfs_gnan.csv as input and gives the gnat chart as ouput.
3.)fcfs-line.py - takes fcfs_data.csv as input and draws the line graph for all the processes.
4.)fcfs-graph.py - takes four files(fcfs_rt1,fcfs_ct1,fcfs_tat1,fcfs_bt1) and shows the convoy effect by displaying four graphs.

RR-

1-RR.cpp -input-input.csv output-gives four files
File format-
    1)rr_data.csv - pid,pname,i/o(cpu),bt,wt,ct,tat
    2)rr_gnan.csv - pid,pname,i/o(cpu),start,end
    3)rr.bt.csv - contains all BT of one test case ',' seperated
    4)rr_wt.csv - contains all WT of one test case ',' seperated
2-RRT.cpp -input-RR.txt and takes 5 time quantums from the user using command line while execution and  output-gives four files 
    1.)rr_tat1.csv- avg burst times all the processes in each line
    2.)rr_rt1.csv-avg response times all the processes in each line
    3.)rr_ct1.csv-avg completion times all the processes in each line
    4.)rr_wt1.csv-avg waiting times all the processes in each line

Graphs-
1.)rr-bar.py- takes fcfs_wt.csv and fcfs_bt.csv as input and pplots a bar plot for each of the process.
2.)rr-gnat.py- takes fcfs_gnan.csv as input and gives the gnat chart as ouput.
3.)rr-line.py - takes fcfs_data.csv as input and draws the line graph for all the processes.
4.)rr-graph.py - takes four files(fcfs_rt1,fcfs_ct1,fcfs_tat1,fcfs_bt1) and shows the how the time quantum is related to all the processes.

And also stored 8 different graphs in the folder as mentioned above, four for each algorithm.

