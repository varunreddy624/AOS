#include<iostream>
#include <algorithm> 
#include <queue> 
#include<iomanip>
#include<climits>
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<queue>
#include<sstream>
#include <chrono>
#include <thread>
#include<unordered_map>
using namespace std;

struct process_struct
{
  int pid;
  string name;
  int arrival_time;
  int burst_time;
  int completion_time;
  int waiting_time;
  int turnaroundtime;
  int rt;
  int start_time;
  int remaining_burst;
};
struct roundrobininfo{
  int pid;
  string name;
  int st;
  int endt;

};
vector<struct roundrobininfo>rrinfo;
unordered_map<int,int>rrmap;
unordered_map<int,string>rrnames;
bool comp(struct process_struct a,struct process_struct b)
{
   int x =a.pid;
   int y =b.pid;
   if(x>y){
       return false;
   }
   return true;
}

bool compare(struct process_struct a,struct process_struct b)
{
   int x =a.arrival_time;
   int y =b.arrival_time;
   if(x>y){
       return false;
   }
   return true;
}
struct io_process{
  int pid;
  int at;
  string name;
  int bt;
  int tat;
  //the tat time is the same as the bt
  int ct;
  //ct=at+bt
  int wt=0;
};



int main(int arc,char *argv[])
{
    ofstream bar;
    ofstream gnan;
    // ofstream tat1;
    // ofstream wt1;
    // ofstream rt1;
    // ofstream ct1;
    ofstream btf;
    string filename("./../allout.txt");
    ofstream allOutput;
    float avg_tat=0,avg_ct=0,avg_wt=0,avg_rt=0;
    allOutput.open(filename, std::ios_base::app);
    bar.open("rr_data.csv",fstream::out);
    gnan.open("rr_gnan.csv",fstream::out);
    btf.open("rr_bt_wt.csv",fstream::out);

    // tat1.open("rr_tat1.csv", fstream::out);
    // wt1.open("rr_wt1.csv", fstream::out);
    // rt1.open("rr_rt1.csv", fstream::out);
    // ct1.open("rr_ct1.csv", fstream::out);
    int n,index;
    int cpu_utilization;
    queue<int> que;
    int current_time = 0,max_completion_time;
    int completed = 0,tq, total_idle_time=0,length_cycle;  
    ifstream fin("input.csv", ios::in);
    vector<struct process_struct>process_block;
    vector<struct io_process>io_block;
    string process;
    int j=0;
    int k=0;
    while(getline(fin, process))
    {
        stringstream ss(process);
        vector<string> params;
        string param;
        for(int i = 0; i < 6; i++)
        {
            if(getline(ss, param, ',')) params.push_back(param);
        }
        if(params[2]=="I/O-bound")
        {
          struct io_process io;
          io.name=params[1];
          io.pid=stoi(params[0]);
          io.at=stoi(params[4]);
          io.bt=stoi(params[5]);
          k++;
          io.tat=io.bt;
          io.ct=io.bt+io.at;
          io_block.push_back(io);
        }
        else{
        struct process_struct pb;
        pb.name=params[1];
        pb.pid=j;
        rrmap[j]=stoi(params[0]);
        pb.arrival_time=stoi(params[4]);
        pb.burst_time=stoi(params[5]);
        pb.remaining_burst=pb.burst_time;
        rrnames[j]=pb.name;
        j++;
        process_block.push_back(pb);
        }
    }
    n=process_block.size();
    bool visited[n]={false},is_first_process=true;
    float sum_tat=0,sum_wt=0,sum_rt=0;
    tq=2;
    bar<<tq<<'\n';
    gnan<<tq<<'\n';
    int m=io_block.size();
    for(int i=0;i<m;i++){
    bar<<io_block[i].pid<<',';
    bar<<io_block[i].name<<',';
    bar<<1<<',';
    gnan<<io_block[i].pid<<',';
    gnan<<io_block[i].name<<',';
    gnan<<1<<',';
    gnan<<io_block[i].at<<',';
    gnan<<io_block[i].ct<<'\n';
    //bar<<io_block[i].ct<<',';
    bar<<io_block[i].bt<<',';
    bar<<io_block[i].wt<<',';
    bar<<io_block[i].ct<<',';
    bar<<io_block[i].tat<<'\n';
    btf<<io_block[i].name<<',';
    btf<<io_block[i].bt<<',';
    btf<<io_block[i].wt<<'\n';
    avg_ct+=io_block[i].ct;
    avg_wt+=io_block[i].wt;
    avg_tat+=io_block[i].tat;
    }
    sort(process_block.begin(),process_block.end(),compare);
    que.push(0);  
    visited[0] = true;
   
    while(completed != n) 
    {
      index = que.front();      
      que.pop();
      
      if(process_block[index].remaining_burst == process_block[index].burst_time)
      {
            process_block[index].start_time = max(current_time,process_block[index].arrival_time);
            total_idle_time += (is_first_process == true) ? 0 : process_block[index].start_time - current_time;
            current_time =  process_block[index].start_time;
            is_first_process = false;
             
      }

      if(process_block[index].remaining_burst-tq > 0)
      {    
            process_block[index].remaining_burst -= tq;
            struct roundrobininfo rr;
            rr.st=current_time;
            current_time += tq;
            rr.pid=index;
            rr.endt=current_time;
            rrinfo.push_back(rr);
            //rr.name=//add name;
          
      }
      else 
      {
            struct roundrobininfo rr;
            rr.st=current_time;
            current_time += process_block[index].remaining_burst;
            rr.pid=index;
            rr.endt=current_time;
            rrinfo.push_back(rr);
            process_block[index].remaining_burst = 0;
            completed++;
            process_block[index].completion_time = current_time;
            process_block[index].turnaroundtime = process_block[index].completion_time - process_block[index].arrival_time;
            process_block[index].waiting_time = process_block[index].turnaroundtime - process_block[index].burst_time;
            process_block[index].rt = process_block[index].start_time - process_block[index].arrival_time;
            sum_tat += process_block[index].turnaroundtime;
            sum_wt += process_block[index].waiting_time;
            sum_rt += process_block[index].rt;
      }

      for(int i = 1; i < n; i++) 
      {
          if(process_block[i].remaining_burst > 0 && process_block[i].arrival_time <= current_time && visited[i] == false) 
          {
            que.push(i);
            visited[i] = true;
          }
      }
      if( process_block[index].remaining_burst> 0) 
          que.push(index);
            
      if(que.empty())
      {
          for(int i = 1; i < n; i++)
          {
            if(process_block[i].remaining_burst > 0)
            {
              que.push(i);
              visited[i] = true;
              break;
            }
          }
      }
   }
  max_completion_time = INT_MIN;
  
  for(int i=0;i<n;i++)
        max_completion_time = max(max_completion_time,process_block[i].completion_time); 
  length_cycle = max_completion_time - process_block[0].arrival_time;  
    
  cpu_utilization = (float)(length_cycle - total_idle_time)/ length_cycle;
  int sum_ct=0;
  sort(process_block.begin(), process_block.end() , comp);
  

  for(int i=0;i<n;i++){
    int x=rrmap[process_block[i].pid];
    bar<<x<<',';
    bar<<process_block[i].name<<',';
    bar<<0<<',';
    bar<<process_block[i].burst_time<<',';
    btf<<process_block[i].name<<',';
    btf<<process_block[i].burst_time<<',';
    btf<<process_block[i].waiting_time<<'\n';
    bar<<process_block[i].waiting_time<<',';
    bar<<process_block[i].completion_time<<',';
    bar<<process_block[i].turnaroundtime<<'\n';
    avg_ct+=process_block[i].completion_time;
    avg_wt+=process_block[i].waiting_time;
    avg_tat+=process_block[i].turnaroundtime;
    avg_rt+=process_block[i].rt;
  }
  for(int i=0;i<rrinfo.size();i++){
    gnan<<rrmap[rrinfo[i].pid]<<',';
    gnan<<rrnames[rrinfo[i].pid]<<',';
    gnan<<0<<',';
    gnan<<rrinfo[i].st<<',';
    gnan<<rrinfo[i].endt<<'\n';
  }
  allOutput << (float)avg_tat/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_ct/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_rt/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_wt/(process_block.size()+io_block.size()) << '\n';
  allOutput.close();
  bar.close();
  gnan.close();
  btf.close();
  return 0;
}