#include<iostream>
#include<queue>
#include<fstream>
#include<string>
#include<sstream>
#include<algorithm>

using namespace std;

typedef long long int lli;

lli current_time = 0;
int RRQ1 = 4; //Round Robin quanta for queue 1
int RRQ2 = 8; //Round Robin quanta for queue 2


struct process
{
    int P_ID;     //process ID
    int AT;       //arrival time
    int BT;       //burst time
    int Priority; //priority time
    int CT;       //completion time
    int TAT;      //turn around time
    int WT;       //waiting time
    int RT;       //response time
    int rem_BT;    //remaining burst time. Used in RR
    bool first_run = true;
    string name;
    bool is_io;
    vector<lli> cpu_burst_start;
    vector<lli> cpu_burst_end;
};

bool cmp_min(process& one, process& two)
{
    if (one.AT == two.AT)
    {
        if (one.Priority == two.Priority)
        {
            return one.P_ID < two.P_ID;
        }
        return one.Priority < two.Priority; //smaller priority gets high prefereeeence
    }
    return one.AT < two.AT;
}

bool cmp_pid(process& p1, process& p2)
{
    return p1.P_ID < p2.P_ID;
}


void read_processes_from_inp(vector<process>& all_cpu_processes, vector<process>& all_io_processes)
{
    ifstream fin("in.txt");
    // string header;
    // getline(fin, header);
    string line;
    process cur_process;
    string param;
    while (getline(fin, line))
    {
        stringstream ss(line);
        getline(ss, param, ',');
        cur_process.P_ID = stoi(param);
        getline(ss, param, ',');
        cur_process.name = param;
        getline(ss, param, ',');
        if (param[0] == 'I') cur_process.is_io = true;
        else cur_process.is_io = false;
        getline(ss, param, ',');
        cur_process.Priority = stoi(param);
        getline(ss, param, ',');
        cur_process.AT = stoi(param);
        getline(ss, param);
        cur_process.BT = stoi(param);
        cur_process.rem_BT = cur_process.BT;
        if(cur_process.is_io) all_io_processes.push_back(cur_process);
        else all_cpu_processes.push_back(cur_process);
    }
    fin.close();
}

void populate_q1(vector<process>& cpu_procs, queue<process*>& q1, int* cpu_procs_idx)
{
    while (*cpu_procs_idx < cpu_procs.size())
    {
        if (cpu_procs[*cpu_procs_idx].AT <= current_time)
        {
            q1.push(&(cpu_procs[*cpu_procs_idx]));
            (*cpu_procs_idx)++;
        }
        else break;
    }
}

void schedule_by_mlfq(vector<process>& cpu_procs, vector<process>& completed)
{
    queue<process*> q1;
    queue<process*> q2;
    queue<process*> q3;
    sort(cpu_procs.begin(), cpu_procs.end(), cmp_min);
    int cpu_procs_idx = 0;
    while(cpu_procs_idx < cpu_procs.size())
    {
        populate_q1(cpu_procs, q1, &cpu_procs_idx);
        if(q1.empty())
        {
            if (cpu_procs_idx >= cpu_procs.size()) break;
            else current_time += cpu_procs[cpu_procs_idx].AT;
        }
        while (!q1.empty())
        {
            process* cur = q1.front();
            cur->cpu_burst_start.push_back(current_time);
            if (cur->first_run)
            {
                //deb(3.5)
                cur->RT = current_time - cur->AT;
                cur->first_run = false;
            }
            cur->rem_BT -= RRQ1;
            //deb(4)
            if (cur->rem_BT <= 0)
            {
                //deb(5)
                current_time += RRQ1 + cur->rem_BT;
                cur->cpu_burst_end.push_back(current_time);
                cur->CT = current_time;
                cur->TAT = cur->CT - cur->AT;
                cur->WT = cur->TAT - cur->BT;
                completed.push_back(*cur);
                q1.pop();
            }
            else
            {
                //deb(6)
                current_time += RRQ1;
                cur->cpu_burst_end.push_back(current_time);
                cur = q1.front();
                q1.pop();
                q2.push(cur);
            }
            populate_q1(cpu_procs, q1, &cpu_procs_idx);
            //deb(7)
            //cout << "for loop: ready_queue size: " << ready_ip.size() << "\n";
        }
    }
    while(!q2.empty())
    {
        process* cur = q2.front();
        cur->cpu_burst_start.push_back(current_time);
        if (cur->first_run)
        {
            //deb(3.5)
            cur->RT = current_time - cur->AT;
            cur->first_run = false;
        }
        cur->rem_BT -= RRQ2;
        //deb(4)
        if (cur->rem_BT <= 0)
        {
            //deb(5)
            current_time += RRQ2 + cur->rem_BT;
            cur->cpu_burst_end.push_back(current_time);
            cur->CT = current_time;
            cur->TAT = cur->CT - cur->AT;
            cur->WT = cur->TAT - cur->BT;
            completed.push_back(*cur);
            q2.pop();
        }
        else
        {
            //deb(6)
            current_time += RRQ2;
            cur->cpu_burst_end.push_back(current_time);
            cur = q2.front();
            q2.pop();
            q3.push(cur);
        }
        //deb(7)
        //cout << "for loop: ready_queue size: " << ready_ip.size() << "\n";
    }
    while(!q3.empty())
    {
        process* cur = q3.front();
        cur->cpu_burst_start.push_back(current_time);
        current_time += cur->rem_BT;
        cur->cpu_burst_end.push_back(current_time);
        cur->CT = current_time;
        cur->RT = current_time - cur->AT;
        cur->TAT = cur->CT - cur->AT;
        cur->WT = cur->TAT - cur->BT;
        completed.push_back(*cur);
        q3.pop();
    }
}

void printVec(vector<process>& v)
{
    for (process p : v)
    {
        cout << p.P_ID << "\t" << p.AT << "\t" << p.BT << "\t" << p.CT << "\t" << p.TAT << "\t" << p.WT << "\t" << p.RT <<"\t";
        if(p.is_io) cout<<"io\n";
        else cout<<"cpu\n";
    }
}

void make_csv_for_gantt(vector<process>& all_completed)
{
    ofstream fout("mlfq_rr48_gantt.csv");
    for(process p : all_completed)
    {
        for(int i = 0; i < p.cpu_burst_start.size(); i++)
        {
            fout<<p.P_ID<<","<<p.name<<",";
            fout<<p.is_io<<",";
            /*if(p.is_io) fout<<p.is_io<<",";
            else fout<<"cpu,";*/
            fout<<p.cpu_burst_start[i]<<","<<p.cpu_burst_end[i]<<"\n";
        }
    }
    fout.close();
}

void write_op_to_csv(vector<process>& completed)
{
    ofstream fout_tat("mlfq_rr48_tat.txt");
    ofstream fout_ct("mlfq_rr48_ct.txt");
    ofstream fout_wt("mlfq_rr48_wt.txt");
    ofstream fout_rt("mlfq_rr48_rt.txt");
    ofstream fout_bt("mlfq_rr24_bt.txt");
    for(int i = 0; i < completed.size(); i++)
    {
        if(i == completed.size() - 1)
        {
            fout_tat<<completed[i].TAT;
            fout_ct<<completed[i].CT;
            fout_wt<<completed[i].WT;
            fout_rt<<completed[i].RT;
            fout_bt<<completed[i].BT;
        }
        else
        {
            fout_tat<<completed[i].TAT<<",";
            fout_ct<<completed[i].CT<<",";
            fout_wt<<completed[i].WT<<",";
            fout_rt<<completed[i].RT<<",";
            fout_bt<<completed[i].BT<<",";
        }
        
    }
    fout_tat.close();
    fout_ct.close();
    fout_wt.close();
    fout_rt.close();
    fout_bt.close();
}

void make_csv_for_avgs(vector<process>& completed)
{
    double avg_tat = 0;
    double avg_rt = 0;
    double avg_ct = 0;
    double avg_wt = 0;
    for(int i = 0; i < completed.size(); i++)
    {
        avg_tat += completed[i].TAT;
        avg_ct += completed[i].CT;
        avg_rt += completed[i].RT;
        avg_wt += completed[i].WT;
    }
    avg_tat /= completed.size();
    avg_ct /= completed.size();
    avg_rt /= completed.size();
    avg_wt /= completed.size();
    ofstream fout("./../../allout.txt", ios_base::app);
    fout<<avg_tat<<",";
    fout<<avg_ct<<",";
    fout<<avg_rt<<",";
    fout<<avg_wt<<"\n";
    fout.close();
}

void make_csv_for_stacked_bars(vector<process>& all_completed)
{
    ofstream fout_bt_ct("mlfq_rr48_bt_wt.csv");
    for(int i = 0; i < all_completed.size(); i++)
    {
        fout_bt_ct<<all_completed[i].name<<","<<all_completed[i].BT<<","<<all_completed[i].WT<<"\n";
    }
    fout_bt_ct.close();
}

void make_csv_for_line(vector<process>& all_completed)
{
    ofstream fout("mlfq_rr48_line.csv");
    for(int i = 0; i < all_completed.size(); i++)
    {
        fout<<all_completed[i].P_ID<<",";
        fout<<all_completed[i].name<<",";
        if(all_completed[i].is_io) fout<<"1,";
        else fout<<"0,";
        fout<<all_completed[i].BT<<",";
        fout<<all_completed[i].WT<<",";
        fout<<all_completed[i].CT<<",";
        fout<<all_completed[i].TAT<<"\n";
    }
    fout.close();
}

int main()
{
    vector<process> cpu_procs;
    vector<process> io_procs;
    read_processes_from_inp(cpu_procs, io_procs);
    vector<process> completed;
    schedule_by_mlfq(cpu_procs, completed);
    for(int i = 0; i < io_procs.size(); i++)
    {
        io_procs[i].cpu_burst_start.push_back(io_procs[i].AT);
        io_procs[i].CT = io_procs[i].AT + io_procs[i].BT;
        io_procs[i].RT = 0;
        io_procs[i].TAT = io_procs[i].BT;
        io_procs[i].WT = 0;
        io_procs[i].cpu_burst_end.push_back(io_procs[i].CT);
    }
    completed.insert(completed.end(), io_procs.begin(), io_procs.end());
    sort(completed.begin(), completed.end(), cmp_pid);
    // cout << "PID \t AT \t BT \t CT \t TAT \t WT \t RT \t cpu/io \n";
    // printVec(completed);
    make_csv_for_gantt(completed);
    make_csv_for_avgs(completed);
    make_csv_for_stacked_bars(completed);
    make_csv_for_line(completed);
    return 0;
}
