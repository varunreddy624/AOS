#include<iostream>
#include<bits/stdc++.h>
#include <random>
#include <fstream>
#include <time.h>
using namespace std;

vector<int> processes;
vector<vector<int>>PCB;
bool compare(vector<int> a,vector<int> b){
    if(a[1]<b[1]){
        return true;
    }
    if(a[1]==b[1])
    {
        if(a[0]<b[0]){
            return true;
        }
    }
    return false;
}


void printTable(int n){
    cout<<"PID  A.T  B.T  W.T  T.T  C.T\n";
    for(int i=0;i<n;i++){
       cout<<PCB[i][0]<<"    "<<PCB[i][1]<<"    "<<PCB[i][2]<<"    "<<PCB[i][3]<<"    "<<PCB[i][5]<<"    "<<PCB[i][5]+PCB[i][1]<<"\n";
    }
}

void fcfs(int n){
    int wait,stime;
    PCB[0].push_back(0);
    PCB[0].push_back(0);
    for(int i=1;i<n;i++){
        stime=(PCB[i-1][2]+PCB[i-1][4]);
        wait=stime-PCB[i][1];
        if(wait<0)
            PCB[i].push_back(0);
        else
            PCB[i].push_back(wait);
        PCB[i].push_back(stime);
    }
    for(int i=0;i<n;i++){
        PCB[i].push_back(PCB[i][2]+PCB[i][3]);
    }
    //printTable(n);
}


void fill_PCB_vector(char* input_file_path)
/*Stores all processes in input file in vector v in the form of their PCBs*/
{
    ifstream fin(input_file_path, ios::in);
    string process;
    while(getline(fin, process))
    {
        stringstream ss(process);
        vector<int> params;
        string param;
        for(int i = 0; i < 3; i++)
        {
            if(getline(ss, param, ',')) params.push_back(stoi(param));
        }
        PCB.push_back(params);
    }
}


int main()
{
    srand(time(NULL));
    ofstream tat1;
    ofstream wt1;
    ofstream ct1;
    ofstream rt1;
    
    tat1.open("fcfs_tat1.csv", fstream::out);
    wt1.open("fcfs_wt1.csv", fstream::out);
    ct1.open("fcfs_ct1.csv", fstream::out);
    rt1.open("fcfs_rt1.csv",fstream::out);
    int line;
    ifstream fin("FCFS.txt",ios::in);
    for (int k = 0; k < 3; ++k)
    {
    PCB.clear();
    int n=5;
    line=1;
    string process;
    while(line<=5 && getline(fin,process))
    {
        line++;
        stringstream ss(process);
        vector<string> params;
        string param;
        for(int i = 0; i < 3; i++)
        {
            if(getline(ss, param, ',')) params.push_back(param);
        }
        vector<int> temp;
        temp.push_back(stoi(params[0]));
        temp.push_back(stoi(params[1]));
        temp.push_back(stoi(params[2]));
        PCB.push_back(temp);
    }
    sort(PCB.begin(),PCB.end(),compare);
    fcfs(n);
    double avg_tat = 0, avg_rt = 0, avg_wt = 0, avg_ct = 0;
    for (unsigned int i = 0; i < PCB.size(); i++)
        {
            avg_tat += PCB[i][5];
            avg_wt += PCB[i][3];
            avg_ct += PCB[i][5]+PCB[i][1];
            avg_rt+=PCB[i][4]-PCB[i][1];
        }
        avg_ct /= PCB.size();
        avg_wt /= PCB.size();
        avg_tat /= PCB.size();
        avg_rt/=PCB.size();
        tat1 << avg_tat << '\n';
        wt1 << avg_wt << '\n';
        ct1 << avg_ct << '\n';
        rt1<<avg_rt<<'\n';
    }

    tat1.close();
    wt1.close();
    ct1.close();
    rt1.close();
    return 0;
}