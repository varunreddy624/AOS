#include<iostream>
#include<bits/stdc++.h>
#include <random>
#include <fstream>
#include <time.h>
using namespace std;


struct process_struct
{
  int pid;
  string name;
  int arrival_time;
  int burst_time;
  int completion_time;
  int waiting_time;
  int turnaroundtime;
  int rt;
  int start_time;
  int remaining_burst;
};

unordered_map<int,int>fcfsmap;
unordered_map<int,string>fcfsnames;
bool compare(struct process_struct a,struct process_struct b)
{
   int x =a.arrival_time;
   int y =b.arrival_time;
   if(x>y){
       return false;
   }
   return true;
}

struct io_process{
  int pid;
  int at;
  string name;
  int bt;
  int tat;
  //the tat time is the same as the bt
  int ct;
  //ct=at+bt
  int wt=0;
};

int main()
{
    ofstream bar;
    ofstream gnan;
    ofstream btf;
    string filename("./../allout.txt");
    ofstream allOutput;
    float avg_tat=0,avg_ct=0,avg_wt=0,avg_rt=0;
    allOutput.open(filename, std::ios_base::app);
    bar.open("fcfs_data.csv",fstream::out);
    gnan.open("fcfs_gnan.csv",fstream::out);
    btf.open("fcfs_bt_wt.csv",fstream::out);
    int n;
    ifstream fin("input.csv", ios::in);
    vector<struct process_struct>process_block;
    vector<struct io_process>io_block;
    string process;
    int j=0;
    int k=0;
    while(getline(fin, process))
    {
        stringstream ss(process);
        vector<string> params;
        string param;
        for(int i = 0; i < 6; i++)
        {
            if(getline(ss, param, ',')) params.push_back(param);
        }
        if(params[2]=="I/O-bound")
        {
          struct io_process io;
          io.name=params[1];
          io.pid=stoi(params[0]);
          io.at=stoi(params[4]);
          io.bt=stoi(params[5]);
          k++;
          io.tat=io.bt;
          io.ct=io.bt+io.at;
          io_block.push_back(io);
        }
        else{
        struct process_struct pb;
        pb.name=params[1];
        pb.pid=j;
        fcfsmap[j]=stoi(params[0]);
        pb.arrival_time=stoi(params[4]);
        pb.burst_time=stoi(params[5]);
        pb.remaining_burst=pb.burst_time;
        fcfsnames[j]=pb.name;
        j++;
        process_block.push_back(pb);
        }
    }
    n=process_block.size();
    int m=io_block.size();
    for(int i=0;i<m;i++){
    bar<<io_block[i].pid<<',';
    bar<<io_block[i].name<<',';
    bar<<1<<',';
    gnan<<io_block[i].pid<<',';
    gnan<<io_block[i].name<<',';
    gnan<<1<<',';
    gnan<<io_block[i].at<<',';
    gnan<<io_block[i].ct<<'\n';
    //bar<<io_block[i].ct<<',';
    bar<<io_block[i].bt<<',';
    bar<<io_block[i].wt<<',';
    bar<<io_block[i].ct<<',';
    bar<<io_block[i].tat<<'\n';
    btf<<io_block[i].name<<',';
    btf<<io_block[i].bt<<',';
    btf<<io_block[i].wt<<'\n';
    avg_ct+=io_block[i].ct;
    avg_wt+=io_block[i].wt;
    avg_tat+=io_block[i].tat;
    }
    n=process_block.size();
    sort(process_block.begin(),process_block.end(),compare);
    int wait,stime;
    process_block[0].waiting_time=0;
    process_block[0].start_time=process_block[0].arrival_time;
    for(int i=1;i<n;i++){
        stime=(process_block[i-1].burst_time+process_block[i-1].start_time);
        wait=stime-process_block[i].arrival_time;
        if(wait<0)
            process_block[i].waiting_time=0;
        else
            process_block[i].waiting_time=wait;
        process_block[i].start_time=stime;
    }
    for(int i=0;i<n;i++){
        process_block[i].turnaroundtime=process_block[i].burst_time+process_block[i].waiting_time;
        process_block[i].completion_time=process_block[i].arrival_time+process_block[i].turnaroundtime;
    }
    for(int i=0;i<n;i++){
    int x=fcfsmap[process_block[i].pid];
    bar<<x<<',';
    bar<<process_block[i].name<<',';
    bar<<0<<',';
    bar<<process_block[i].burst_time<<',';
    bar<<process_block[i].waiting_time<<',';
    btf<<process_block[i].name<<',';
    btf<<process_block[i].burst_time<<',';
    btf<<process_block[i].waiting_time<<'\n';
    bar<<process_block[i].completion_time<<',';
    bar<<process_block[i].turnaroundtime<<'\n';
    gnan<<fcfsmap[process_block[i].pid]<<',';
    gnan<<process_block[i].name<<',';
    gnan<<0<<',';
    gnan<<process_block[i].start_time<<',';
    gnan<<process_block[i].completion_time<<'\n';
    avg_ct+=process_block[i].completion_time;
    avg_wt+=process_block[i].waiting_time;
    avg_tat+=process_block[i].turnaroundtime;
    avg_rt+=process_block[i].start_time-process_block[i].arrival_time;
    }

    allOutput << (float)avg_tat/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_ct/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_rt/(process_block.size()+io_block.size()) << ',';
    allOutput << (float)avg_wt/(process_block.size()+io_block.size()) << '\n';
    allOutput.close();
    bar.close();
    btf.close();
    gnan.close();
    return 0;
}